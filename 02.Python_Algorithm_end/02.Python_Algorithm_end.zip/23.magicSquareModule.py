#import magicSquare
from magicSquare import magicSquare

if __name__ == "__main__":
    n = int(input("숫자 : "));
    #magicSquare.magicSquare(n)
    magicSquare(n)
